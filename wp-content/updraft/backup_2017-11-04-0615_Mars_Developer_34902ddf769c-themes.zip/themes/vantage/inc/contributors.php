<?php
return json_decode( '{
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 1755,
		"score": 86.73469008309958,
		"percent": 50.48517407596701
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 2364,
		"score": 44.07439096009102,
		"percent": 25.654133286007873
	},
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 643,
		"score": 38.80871882011248,
		"percent": 22.589173068140152
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 26,
		"score": 1.34190268207765,
		"percent": 0.7810737599084089
	},
	"d203744279876c5eda043108e2611648": {
		"name": "Alex S",
		"email": "d203744279876c5eda043108e2611648",
		"loc": 4,
		"score": 0.5416961363970186,
		"percent": 0.3153020287047868
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 23,
		"score": 0.30090104405169565,
		"percent": 0.1751437812717806
	}
}', true );