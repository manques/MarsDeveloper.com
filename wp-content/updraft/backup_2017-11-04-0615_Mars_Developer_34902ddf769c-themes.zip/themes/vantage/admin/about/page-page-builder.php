<h3><?php _e( 'Enhanced by Page Builder', 'vantage' ) ?></h3>
<p>
	<?php printf( __( "Vantage integrates, beautifully, with our %sfree Page Builder%s plugin.", 'vantage' ), '<a href="https://siteorigin.com/page-builder/">', '</a>' ) ?>
	<?php _e( 'This powerful plugin gives you full drag and drop capabilities right inside Vantage.', 'vantage' ) ?>
</p>