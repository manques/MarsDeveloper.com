			
<!-- admin menu -->
<div class="fa fa-check-square"></div>
<div class="fa fa-check-square-o"></div>
<div class="fa fa-circle"></div>
<div class="fa fa-circle-o"></div>
<div class="fa fa-dot-circle-o"></div>
<div class="fa fa-minus-square"></div>
<div class="fa fa-minus-square-o"></div>
<div class="fa fa-plus-square"></div>
<div class="fa fa-plus-square-o"></div>
<div class="fa fa-square"></div>
<div class="fa fa-square-o"></div>
